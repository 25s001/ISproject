#pragma once

// MinGW installs this Windows SDK compatibility header with a lowercase name.
#include <sdkddkver.h>
